// Uncomment the next line to use precompiled headers
#include "pch.h"
// uncomment the next line if you do not use precompiled headers
//#include "gtest/gtest.h"
//
// the global test environment setup and tear down
// you should not need to change anything here
class Environment : public ::testing::Environment
{
public:
    ~Environment() override {}

    // Override this to define how to set up the environment.
    void SetUp() override
    {
        //  initialize random seed
        srand(time(nullptr));
    }

    // Override this to define how to tear down the environment.
    void TearDown() override {}
};

// create our test class to house shared data between tests
// you should not need to change anything here
class CollectionTest : public ::testing::Test
{
protected:
    // create a smart point to hold our collection
    std::unique_ptr<std::vector<int>> collection;

    void SetUp() override
    { // create a new collection to be used in the test
        collection.reset(new std::vector<int>);
    }

    void TearDown() override
    { //  erase all elements in the collection, if any remain
        collection->clear();
        // free the pointer
        collection.reset(nullptr);
    }

    // helper function to add random values from 0 to 99 count times to the collection
    void add_entries(int count)
    {
        assert(count > 0);
        for (auto i = 0; i < count; ++i)
            collection->push_back(rand() % 100);
    }
};

// When should you use the EXPECT_xxx or ASSERT_xxx macros?
// Use ASSERT when failure should terminate processing, such as the reason for the test case.
// Use EXPECT when failure should notify, but processing should continue

// Test that a collection is empty when created.
// Prior to calling this (and all other TEST_F defined methods),
//  CollectionTest::StartUp is called.
// Following this method (and all other TEST_F defined methods),
//  CollectionTest::TearDown is called
TEST_F(CollectionTest, CollectionSmartPointerIsNotNull)
{
    // is the collection created
    ASSERT_TRUE(collection);

    // if empty, the size must be 0
    ASSERT_NE(collection.get(), nullptr);
}

// Test that a collection is empty when created.
TEST_F(CollectionTest, IsEmptyOnCreate)
{
    // is the collection empty?
    ASSERT_TRUE(collection->empty());

    // if empty, the size must be 0
    ASSERT_EQ(collection->size(), 0);
}

/* Comment this test out to prevent the test from running
 * Uncomment this test to see a failure in the test explorer 
TEST_F(CollectionTest, AlwaysFail)
{
    FAIL();
}
*/
// TODO: Create a test to verify adding a single value to an empty collection
TEST_F(CollectionTest, CanAddToEmptyVector)
{
    // is the collection empty?
    EXPECT_TRUE(collection->empty());

    // if empty, the size must be 0
    ASSERT_EQ(collection->size(), 0);

    // add entries
    add_entries(1);

    // is the collection still empty?
    EXPECT_TRUE(!collection->empty());

    // if not empty, what must the size be?
    ASSERT_TRUE(collection->size() > 0);
}

// TODO: Create a test to verify adding five values to collection
TEST_F(CollectionTest, CanAddFiveValuesToVector)
{
    // check if collection is empty
    EXPECT_TRUE(collection->empty());

    // add entries
    add_entries(5);

    // if not empty, what must the size be?
    ASSERT_TRUE(collection->size() >= 5);
}

// TODO: Create a test to verify that max size is greater than or equal to size for 0, 1, 5, 10 entries
TEST_F(CollectionTest, IsSizeGreaterThanEntries)
{
    // is max size greater than or equal to 0
    ASSERT_TRUE(collection->size() >= 0);

    add_entries(1); // collection size == 1

    // is max size greater than or equal to 1
    ASSERT_TRUE(collection->size() >= 1);

    add_entries(5); // collection size == 6

    // is max size greater than or equal to 5
    ASSERT_TRUE(collection->size() >= 5);

    add_entries(10); // collection size == 16

    // is max size greater than or equal to 10
    ASSERT_TRUE(collection->size() >= 10);
}

// TODO: Create a test to verify that capacity is greater than or equal to size for 0, 1, 5, 10 entries
TEST_F(CollectionTest, CapacityIsGreaterThanOrEqualToEntries)
{
    // is capacity greater than or equal to 0
    ASSERT_TRUE(collection->capacity() >= 0);

    // add 1 entries
    add_entries(1); // collection capacity == 1

    // is capacity greater than or equal to 1
    ASSERT_TRUE(collection->capacity() >= 1);

    // add 5 entries
    add_entries(5); // collection capacity == 6

    // is capacity greater than or equal to 5
    ASSERT_TRUE(collection->capacity() >= 5);

    // add 10 entries
    add_entries(10); // collection capacity == 19
    
    // Used to test capacity and output
    std::cout << "Collection Capacity: " << collection->capacity() << std::endl;

    // is capacity greater than or equal to 10
    ASSERT_TRUE(collection->capacity() >= 10); 
}

// TODO: Create a test to verify resizing increases the collection
TEST_F(CollectionTest, DoesResizingIncreaseCollection)
{
    // is collection size equal to 0
    EXPECT_EQ(collection->size(), 0);

    // resize collection to 1
    collection->resize(1);

    // is collection size equal to 0
    ASSERT_TRUE(collection->size() > 0);

    // resize collection to 5
    collection->resize(5);

    // is collection size equal to 5
    ASSERT_EQ(collection->size(), 5);
}

// TODO: Create a test to verify resizing decreases the collection
TEST_F(CollectionTest, DoesResizingDecreaseCollection)
{
    // set collection size to 10
    collection->resize(10);

    // is collection size correct to set size
    EXPECT_EQ(collection->size(), 10);

    // resize collection to 5
    collection->resize(5);

    // is collection size equal to 5
    ASSERT_EQ(collection->size(), 5);
}

// TODO: Create a test to verify resizing decreases the collection to zero
TEST_F(CollectionTest, DoesResizingDecreaseCollectionToZero)
{
    // set collection size to 10
    collection->resize(10);

    // is collection size correct to set size
    EXPECT_EQ(collection->size(), 10);

    // resize collection to 0
    collection->resize(0);

    // is collection size equal to 5
    ASSERT_EQ(collection->size(), 0);
}

// TODO: Create a test to verify clear erases the collection
TEST_F(CollectionTest, DoesEraseClearCollection) 
{
    // set collection size to 10
    collection->resize(10);

    // is collection size correct to set size
    EXPECT_EQ(collection->size(), 10);

    // clear collection
    collection->clear();

    // is collection size equal to 0
    ASSERT_EQ(collection->size(), 0);
}

// TODO: Create a test to verify erase(begin,end) erases the collection
TEST_F(CollectionTest, WillEraseWorkOnCollection)
{
    // set some values (from 1 to 10)
    for (unsigned i = 1; i <= 10; i++) collection->push_back(i);

    // Verify collection size
    std::cout << "Collection Size: " << collection->size() << std::endl;

    // erase the 6th element
    collection->erase(collection->begin() + 5);

    // check to see if value is correct at the position (should no longer be 6 at position 5)
    std::cout << "Collection Value at position 5: " << collection->at(5) << std::endl;

    // is collection one less?
    ASSERT_EQ(collection->size(), 9);
}

// TODO: Create a test to verify reserve increases the capacity but not the size of the collection
TEST_F(CollectionTest, WillReserveIncreaseCapacityButNotSizeOfCollection) 
{ 
    // set some values (from 1 to 10). Sets collection size to 10. Capacity is 13
    for (unsigned i = 1; i <= 10; i++) collection->push_back(i);

    // reserve 100 capacity for collection
    collection->reserve(100);

    // is collection size unchanged
    ASSERT_TRUE(collection->size() >= 10);

    // is collection capacity greater than previous size
    ASSERT_EQ(collection->capacity(), 100);

    // Used to test collection size
    std::cout << "Collection size: " << collection->size() << std::endl;

    // Used to test capacity and output
    std::cout << "Collection Capacity: " << collection->capacity() << std::endl;
}

// TODO: Create a test to verify the std::out_of_range exception is thrown when calling at() with an index out of bounds
// NOTE: This is a negative test
TEST_F(CollectionTest, IsExceptionThrownWhenIndexOutOfBounds)
{
    // set some values (from 1 to 10).
    for (unsigned i = 1; i <= 10; i++) collection->push_back(i);

    // Output test to check values in positions.
    std::cout << "Collection Values : ";
    for (unsigned i = 0; i < collection->size(); i++)
        std::cout << ' ' << collection->at(i);
    std::cout << '\n';

    // is exception caught for index out of range 
    ASSERT_THROW(collection->at(25), std::out_of_range);
}

// TODO:Create 2 unit tests of your own to test something on the collection - do 1 positive & 1 negative
TEST_F(CollectionTest, IsLastValueRemovedWhenPopped) // Positive test
{
    // set some values (from 1 to 10).
    for (unsigned i = 1; i <= 10; i++) collection->push_back(i);

    collection->pop_back();

    // Output test to check values in positions.
    std::cout << "Collection Values : ";
    for (unsigned i = 0; i < collection->size(); i++)
        std::cout << ' ' << collection->at(i);
    std::cout << '\n';

    // if size equals 9 then pop_back removed the last value
    ASSERT_EQ(collection->size(), 9);
}

TEST_F(CollectionTest, IsErrorNotCaughtWhenDivideByZero) // Negative Test
{
    // set some values (from 0 to 4).
    for (int i = 0; i <= 4; i++) collection->push_back(i);

    // Output test to check values in positions.
    std::cout << "Collection Values : ";
    for (unsigned i = 0; i < collection->size(); i++)
        std::cout << ' ' << collection->at(i);
    std::cout << '\n';

    //display message indicating numbers checked.
    std::cout << "Position 4 is divided by position 0" << std::endl;

    // is error not caught: unknown file: error: SEH exception with code 0xc0000094 thrown in the test body.
    // attempted to divide by zero using values at positions. 
    ASSERT_NO_THROW(collection->at(4) / collection->at(0)); 
}